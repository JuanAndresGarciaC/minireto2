//: Velocimetro Digital
import UIKit

enum Velocidades : Int{
    case apagado = 0,
    velocidadBaja = 20,
    velocidadMedia = 50,
    velocidadAlta = 120
    
    init( velocidadInicial : Velocidades ){
        self = velocidadInicial
    }
}

class Auto {
    
    var velocidad : Velocidades = .apagado
    
    init( velocidad : Velocidades ){
    self.velocidad = velocidad
    }
    
    func cambioDeVelocidad( ) -> (actual : Int, velocidadEnCadena: String){
  
        if velocidad == .apagado{
            velocidad = .velocidadBaja
            print("0, Apagado")
            return(0, "Apagado")
        } else if velocidad == .velocidadBaja{
            velocidad = .velocidadMedia
            print("20, Velocidad Baja")
            return(20, "Velocidad Baja")
        } else if velocidad == .velocidadMedia{
            velocidad = .velocidadAlta
            print("50, Velocidad Media")
            return(50, "Velocidad Media")
        }else if velocidad == .velocidadAlta{
            velocidad = .velocidadMedia
            print("20, Velocidad Alta")
            return(20, "Velocidad Alta")
        }else{
            return(0, "apagado")
        }
    }
}
var auto = Auto(velocidad: .apagado)



